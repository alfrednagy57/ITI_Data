 //alert("hi this  is a js");
 /*
 kjflkdjflksdjflkdsjflk
 */
// console.log('hi this is a js');
// console.log(2*50)

//  fname="ahmed";
// console.log(fname)
// fname="hamada";
// console.log(fname);
// var fname;
// console.log(fname);
// var sname,lname;
// sname="ali"
// //lname="mido"
// console.log(lname)
// //console.log(xname);
// var x=50;
// x=x+1
// var age=x;
// console.log(age);
// var age="mido"
// {
// let address="egypt";
// console.log(address);

// }
// let address="dddd";
// console.log(address);
// //console.log(address);
// {
// const person="hmada";

// }
let userName="admin";
let UserName;

//alert(userName)
console.log(userName);
// var x=confirm("Are you sure you want to delete");
// console.log(x);
let age=prompt("enter your age");
//console.log(age);
let xname=prompt("Enter your name");
alert ("your name is " + xname +" and your age is " + age);


