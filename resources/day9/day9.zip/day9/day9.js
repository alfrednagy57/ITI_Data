// var sname = "ahmed";
// console.log(window);
// console.log(sname.padEnd(50, "_*_"));
// let str = `hi my name ' "
//  is ${sname}`;
// let str1 = "hi my name  \n ' \"is " + sname;
// console.log(str, str1);

// const settings = { size: "" };
// //const setting = {}// { size: false };

// const size = settings.size || 42; //42
// const sizes = settings.size ?? 42; //0
// console.log(size);
// console.log(sizes);

// let obj = { sname: "ahmed" };
// console.log(obj.address?.city);
// let arr = [10, 20, 30];
// let x = arr[0];
// let y = arr[1];
// let z = arr[2];
// let [x, y, ...z] = [10, 20, 30, 40, 50];
// console.log(x, y, z);
// function fun() {
//   return [x, y];
// }
// let [x1, y1] = fun();
// console.log(x1, y1);
//let obj = { sname: "ahmed", age: 50 };
// let {
//   sname: studentName,
//   address: { city, street },
//   studentList: [x, y],
//   studentList,
//   address,
// } = {
//   sname: "ahmed",
//   age: 50,
//   address: { city: "city1", street: "street1" },
//   studentList: ["st1", "st2"],
// };
// console.log(studentName, city, street, x, y, studentList, address);
// let obj = {
//   sname: "ahmed",
//   age: 50,
//   move: function () {
//     console.log(obj.sname + " is move");
//   },
// };
// obj.move();
// function ayhaga() {
//   obj.sname = "ahmed ali";
// }
// let obj = {
//   sname: "ahmed",
//   age: 50,
//   move: function () {
//     console.log(obj.sname + " is move");
//   },
// };
// Object.freeze(obj);
// Object.seal(obj);
// obj.age = 60;
// delete obj.age;
// obj.fname = "kjljk";
// console.log(obj);
// Object.defineProperty(obj, "fname", {
//   //configurable: true,
//   //writable: true,
//   //enumerable: true,
//   value: "ali",
// });
// //delete obj.fname;
// //obj.fname = "mido";
// console.log(obj);
// console.log(Object.keys(obj));
// function Person(sname, age) {
//   this.sname = sname;
//   this.age = age;
//   //   this.move = function () {
//   //     console.log(this.sname + " is move");
//   //   };
// }
// Person.prototype.move = function () {
//   console.log(this.sname + " is move");
// };
// let person = new Person();
// person.sname = "ahmed";
// person.age = 50;
// person.move();
// console.log(person);
// console.log([]);
// class Person {
//   constructor(sname, age) {
//     this.sname = sname;
//     this.age = age;
//   }
//   move() {
//     console.log(this.sname + " is move");
//   }
// }
// let person = new Person("ahmed", 50);
// person.move();
// console.log(person);
// let person2 = new Person();
// person2.age = 30;
// person2.sname = "mido";
// console.log(person2);
// class Employee extends Person {
//   #fname = "";
//   constructor(sname, age, dep) {
//     super(sname, age);
//     this.dap = dep;
//   }
//   changName(empName) {
//     this.#fname = empName;
//   }
//   static Create(sname, age, dep) {
//     return new Employee(sname, age, dep);
//   }
// }

// let emp = new Employee("hamada", 55, "hr");
// emp.changName("new name");

// emp.move();
// console.log(emp);
// let emp2 = Employee.Create("hamada5", 55, "br");
// console.log(emp2);
let arr = [10, 20, 22, 15, 10, 40, 30, 40];
console.log(arr.find((x) => x > 25));
let arr2 = [];
arr.forEach((x) => arr2.push(x * 2));
console.log(arr2);
console.log(arr.map((x) => x * 2));
let set = new Set(arr);
set.add(20);
set.delete(20);
console.log(set);
console.log(Array.from(set));
