

// function calc(x,y=0){//let x,y=0;
//     // let x=5;
//     // let y=6;
//     console.log(x+y,"hi",5+50);
// }
//calc(5,6);
// calc(10);


// function calc2(...x){
//     console.log(x)

// }
// calc2(10);
// calc2(30,20)
// calc2(30,50,60,55,);
function calc3(x,y){
    return x*y;
}
// let num=calc3(5,6);
// console.log(num);

// const fun1=function (x,y){
// //    let x=5;
// //     let y=6;
//     console.log(x+y);
// }
// fun1(10,60)
// function fin2(){
//     console.log("jjj")
// }
// console.log(fin2);
// let fun2= (x=0,y)=> console.log("hi",x,y);
// fun2(50,60);
// let fun3=Function("x","y","return x+y");
// console.log(fun3(50,60));
/*************************************** */
// function fun1(x){
//     let z=100;
//     let fun2=function(){
//         let z1=200;
//         function fun3(y){
//             console.log(x+y,"---->",3);
//             fun4(6,6)
//             fun5();
//         }
//         fun3(30)
//         console.log(2)
//         function fun5(){
//             console.log("kjkjlk")
//         }
//     }
//    fun2()
//     console.log(x)
// }
// fun1(1)
// //fun2()
// function fun4(x,y){
//     console.log(x*y);
// }
/*********************************************** */
//function print(callback){//callback=printConsole  =printalet
//     let x=5;
//     let y=10;
//     callback(x+y);//printConsole(x+y)  //printalert(x+y)
// }
// function printConsole(a){
//     console.log(a)
// }
// function printAlert(a){
//     alert(a)
// }
// print(printConsole)
// print(printAlert)
/************************************ */
// (function (x){
//     console.log("mi my name is js",x)
// })(50);
// function fun1(){
//     try {
//          console.log(x);
//     } catch (e) {
//         console.log("user error",e)
//     }finally{

//     }
   
//     // console.log("my name is ahmed")
// }
// fun1()
// console.log("my name is ahmed")

const obj={fname:"ahmed",age:50}
const obj3={fname:"ahmed",age:50}
const obj4=obj;
if(obj.age==obj3.age){
console.log("true")
}else{console.log("false")}


if(obj===obj4){
console.log("true")
}else{console.log("false")}
// obj.age=49;
// //delete obj.fname;
// console.log(obj.age, obj.fname)
// console.log(obj)
// let x=5;
// //obj={fname:"ahmed",age:60}
// const obj1=obj;
// obj1.age=60;
// console.log(obj1.age)
// console.log(obj.age)
// //////////////////////////////
// function xyz(fff){//let fff=obj1
//     fff.age=30;
// }
// xyz(obj1);
// console.log(obj1)
obj.sname="ali";
console.log(obj);
let newObj=Object.assign({},obj)
newObj.age=30;
console.log(newObj,"==>new obj")
console.log(obj, "--->obj")
console.log(Object.keys(obj))
console.log(Object.entries(obj))
console.log(obj.age)
for (let x in obj) {
   // console.log(key,obj[key])
console.log(x,obj[x])
}

