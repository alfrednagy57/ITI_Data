// const arr = [10, 20, 30, 40, 50, 55, 60];
// //const arr1=new Array();
// console.log(arr[1]);
// arr.push(51, 52);
// arr.pop();
// arr.shift();
// arr.unshift(18, 19);
// let newarr = arr.concat(1, 2, 3, 4);
// console.log(newarr);
// let arr2 = newarr.filter(function (item) {
//   return item > 20;
// });
// let arr3 = newarr.filter(function (x) {
//   return x > 10 && x < 45;
// });
// console.log(arr3);
// console.log(arr2);
// newarr;
//   .sort(function (a, b) {
//     return a - b;
//   })
//   .reverse();
//newarr.reverse();
//debugger;
// for (let i = 0; i < newarr.length; i++) {
//   console.log(newarr[i]);
// }
// console.log("---------------------------------");
// for (let i in newarr) {
//   console.log(newarr[i]);
// }
// console.log("---------------------------------");
// for (let item of newarr) {
//   console.log(item);
// }
// console.log("---------------------------------");
// newarr.forEach(function (item, index) {
//   console.log(index, ":", item);
// });
// console.log(newarr.slice(2, 7));
// newarr.splice(9, 3, 11, 22, 33, 44, 55, 66);
// console.log(newarr);
