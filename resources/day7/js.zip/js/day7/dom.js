let div1 = document.getElementById("mydiv");
// div1.style.color = "red";
// console.log(div1.innerHTML);
// console.log(div1.innerText);
// div1.innerText = "Hello world";
// div1.innerHTML = "<p> hello from js</p>";
// div1.setAttribute("title", "Hello from js");
// console.log(div1);
// let txt = document.getElementById("userdata");
// txt.value = "admin";
// console.log(txt.value);
// console.log(txt);
// let p = document.getElementsByTagName("p");
// p[1].classList.add("one");
// p[0].classList.toggle("two");
// console.log(p);
// let one = document.getElementsByClassName("one");

// console.log(one);
// let mydiv = document.querySelector("#mydiv");
// let classl = document.querySelector(".one");
// let inputtxt = document.querySelector("input[type=text]");
// inputtxt.value = "mido";
// console.log(mydiv);
// document.querySelectorAll("input[type=text"); //array

// let div = document.createElement("div");
// div.innerHTML = "<p>hi from js</p>";
// div.style.color = "red";
// div1.appendChild(div);
// div1.removeChild(div);
// document.write('<div class="one">any text</div>');

// let tbl = document.createElement("table");

// let tr = document.createElement("tr");

// let td1 = document.createElement("td");
// let txt1 = document.createTextNode("row1 col1");

// let td2 = document.createElement("td");
// let txt2 = document.createTextNode("row1 col2");
// tbl.appendChild(tr);
// tr.appendChild(td1);
// tr.appendChild(td2);

// td2.appendChild(txt2);
// td1.appendChild(txt1);
// tbl.setAttribute("border", "1");
// div1.appendChild(tbl);
console.log(document.cookie);
document.cookie = "name='ahmed'";
console.log(document.cookie);

localStorage.setItem("userdata", "ahmed ali");
console.log(localStorage.getItem("userdata"));
const obj = { fname: "ahmed", age: 50 };

localStorage.setItem("person", JSON.stringify(obj));
console.log(JSON.parse(localStorage.getItem("person")));
console.log(localStorage.getItem("person"));
